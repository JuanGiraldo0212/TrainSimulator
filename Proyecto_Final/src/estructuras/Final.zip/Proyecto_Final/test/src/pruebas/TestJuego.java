package pruebas;

import static org.junit.Assert.assertArrayEquals;

import org.junit.Test;

import Excepciones.QueueException;
import junit.framework.TestCase;
import mundo.*;

public class TestJuego extends TestCase{

	
	private Juego juego;
	
	public void setUpEscenario2(){
		juego = new Juego();
		Vertex[] Vlist = new Vertex[5];
		Vlist[0] = new Vertex("0","Estacion",5,30,40);
		Vlist[1] = new Vertex("1","Estacion",5,60,80);
		Vlist[2] = new Vertex("2","Estacion",5,120,160);
		Vlist[3] = new Vertex("3","Estacion",5,70,30);
		Vlist[4] = new Vertex("4","Estacion",5,20,40);
		
		int[][] grafoMatrizAd = {{0,99999,99999,57,45},{99999,0,99999,45,28},{99999,99999,0,57,99999},{57,45,57,0,60},{45,28,99999,60,0}};
		
		juego.setGrafoMatrizAd(grafoMatrizAd);
		juego.setVertices(Vlist);
	}
	
	public void setUpEscenario1(){
		juego = new Juego();
		Vertex[] Vlist = new Vertex[5];
		Vlist[0] = new Vertex("0","Estacion",5,30,40);
		Vlist[1] = new Vertex("1","Estacion",5,60,80);
		Vlist[2] = new Vertex("2","Estacion",5,120,160);
		Vlist[3] = new Vertex("3","Estacion",5,70,30);
		Vlist[4] = new Vertex("4","Estacion",5,20,40);
		
		int[][] grafoMatrizAd = {{0,0,0,1,1},{0,0,0,1,1},{0,0,0,1,0},{1,1,1,0,1},{1,1,0,1,0}};
		
		juego.setGrafoMatrizAd(grafoMatrizAd);
		juego.setVertices(Vlist);
	}
	
	@Test
	public void testBFS() throws QueueException {
		setUpEscenario1();
		assertEquals("(0,3) (0,4) (3,1) (3,2) ",juego.BFS(juego.getGrafoMatrizAd()));
	}
	@Test
	public void testDFS() {
		setUpEscenario1();
		assertEquals("(0,3) (3,1) (1,4) (3,2) / ",juego.DFS(juego.getGrafoMatrizAd()));
	}
	@Test
	public void testFW() {
		setUpEscenario2();
		int[][] expected= {{0,73,114,57,45},{73,0,102,45,28},{114,102,0,57,117},{57,45,57,0,60},{45,28,117,60,0}};
		int[][] actual = juego.floydWarshall(juego.getGrafoMatrizAd());
		assertArrayEquals(expected,actual);
	}
	
	
}
