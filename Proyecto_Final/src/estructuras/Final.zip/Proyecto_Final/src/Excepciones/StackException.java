package Excepciones;

public class StackException extends Exception{

	public StackException(String mensaje)
	{
		super(mensaje);
	}
}
