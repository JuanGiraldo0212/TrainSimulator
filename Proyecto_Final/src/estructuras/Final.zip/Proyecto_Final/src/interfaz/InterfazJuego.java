package interfaz;
import java.awt.*;
import java.io.File;

import javax.swing.*;

import hilos.HiloTren;
import mundo.Juego;
public class InterfazJuego extends JFrame{
	public final static int ANCHO =2000;
	public final static int LARGO =1000;
	
	private Juego mundo;
	private PanelInicio inicio;
	private PanelJuego juego;
	private HiloTren tren;
	
	public InterfazJuego(){
		mundo=new Juego();
		setTitle("Jueguirris");
		setLayout(new BorderLayout());
		setSize(new Dimension(ANCHO, LARGO));
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setResizable(false);
		inicio= new PanelInicio(this);
		add(inicio,BorderLayout.CENTER);
		
	}
	
	public static void main(String[] args) {
		InterfazJuego ventana= new InterfazJuego();
		ventana.setVisible(true);
	}
	
	public void cargarArchivo(){
		JFileChooser fc = new JFileChooser("./data");
		int result = fc.showOpenDialog(this);
		if(result==JFileChooser.APPROVE_OPTION){
			File file = fc.getSelectedFile();
			String[] opciones = {"Matriz de Adyacencia", "Lista de Adyacencia"};
			String tipo = null;
		    do
		    {
			    tipo = (String) JOptionPane.showInputDialog(null, "Escoge el tipo de implementaci�n", "The Choice of a Lifetime", JOptionPane.QUESTION_MESSAGE, null, opciones, opciones[0]);
		    	if(tipo != null)
		    	{
		    		if(tipo.equals("Matriz de Adyacencia"))
		    		{
		    			mundo.cargarGrafoMatrizAd(file);
		    		}
		    		else if(tipo.equals("Lista de Adyacencia"))
		    		{
		    			mundo.cargarGrafoListaAd(file);
		    		} 		
		    	}
		    }while(tipo == null);
		    
		}
		cambiarPantalla();
		
	}
	
	public void cambiarPantalla(){
		remove(inicio);
		if(mundo.getGrafoMatrizAd() != null)
		{
			juego= new PanelJuego(mundo.getGrafoMatrizAd(),mundo.getVertices(),mundo.getTren(), mundo);
		}
		else if(mundo.getGrafoListaAd() != null)
		{
			juego = new PanelJuego(mundo.getGrafoListaAd(), mundo.getVertices(), mundo.getTren());
		}
		add(juego,BorderLayout.CENTER);
		pack();
		setSize(new Dimension(ANCHO, LARGO));
		iniciarHilos();
	}
	
	public void iniciarHilos(){
		tren=new HiloTren(mundo.getTren(),this);
		tren.start();
	}
	
	public void actualizar(){
		juego.repaint();
		}
	public PanelJuego getPanelJuego(){
		return juego;
	}
	
	public void cambiarSeleccionado(){
		juego.cambiarSeleccionado();
	}

}
