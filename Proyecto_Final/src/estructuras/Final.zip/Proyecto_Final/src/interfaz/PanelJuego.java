package interfaz;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import java.util.Hashtable;

import javax.swing.*;

import mundo.Juego;
import mundo.Tren;
import mundo.Vertex;
public class PanelJuego extends JPanel implements KeyListener{

	private int[][] grafoMatrizAd;
	private Hashtable<String, ArrayList<int[]>> grafoListaAd;
	private Vertex[] vertices;
	private Tren tren;
	private Vertex seleccionado;
	private Juego principal;
	
	public PanelJuego(int[][] mat, Vertex[] ver,Tren tren, Juego principal){
		setLayout(new BorderLayout());
		setFocusable(true);
		addKeyListener(this);
		grafoMatrizAd=mat;
		grafoListaAd = null;
		vertices=ver;
		this.principal = principal;
		this.tren=tren;
		seleccionado=tren.getActual();
		cambiarSeleccionadoDer();
	}
	public PanelJuego(Hashtable<String, ArrayList<int[]>> grafoListaAd, Vertex[] vertices, Tren tren)
	{
		setLayout(new BorderLayout());
		setFocusable(true);
		addKeyListener(this);
		this.grafoListaAd = grafoListaAd;
		grafoMatrizAd = null;
		this.vertices= vertices;
		this.tren=tren;
		if(vertices[grafoListaAd.get(tren.getActual().getCodigo()).get(0)[0]].getCodigo().equalsIgnoreCase(tren.getActual().getCodigo()))
		{
			seleccionado = vertices[grafoListaAd.get(tren.getActual().getCodigo()).get(1)[0]];
		}
		else
		{
			seleccionado = vertices[grafoListaAd.get(tren.getActual().getCodigo()).get(0)[0]];
		}
		 
	}
	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;
		g2.drawString("Velocidad: "+tren.getVelocidad(), 400, 20);
		g2.drawImage(new ImageIcon("./data/helpButt.png").getImage(), 700, 600, this);
		if(grafoMatrizAd != null)
		{
			for(int i=0;i<grafoMatrizAd.length;i++){
				Vertex actual=vertices[i];
				for(int j=0;j<grafoMatrizAd[0].length;j++){
					if(grafoMatrizAd[i][j]!=0){
						Vertex relacion=vertices[j];
						g2.setColor(Color.BLACK);
						g2.setStroke(new BasicStroke(5));
						g2.drawLine(actual.getPosX()+20, actual.getPosY()+20, relacion.getPosX()+20, relacion.getPosY()+20);
					}
				}
			}
			Vertex inicial = tren.getActual();
			g2.setColor(Color.green);
			g2.drawLine(inicial.getPosX()+20, inicial.getPosY()+20, seleccionado.getPosX()+20, seleccionado.getPosY()+20);
			g2.setStroke(new BasicStroke(2));
			g2.setColor(Color.RED);
//			if(principal.isDijkstra()) {
//				
//				ArrayList<Integer> temp = principal.dijkstra(principal.getGrafoMatrizAd(), Integer.parseInt(tren.getSalida().getCodigo()), 15);
//				for(int i = 0;i<temp.size()-1;i++) {
//					g2.setColor(Color.RED);
//					g2.setStroke(new BasicStroke(5));
//					g2.drawLine(principal.getVertices()[temp.get(i)].getPosX()+20, principal.getVertices()[temp.get(i)].getPosY()+20, principal.getVertices()[temp.get(i+1)].getPosX()+20, principal.getVertices()[temp.get(i+1)].getPosY()+20);
//				}
//			}
			for(int i=0;i<vertices.length;i++){
				g2.setColor(Color.RED);
				g2.fillOval(vertices[i].getPosX(), vertices[i].getPosY(), 40, 40);
				g2.setColor(Color.BLACK);
				g2.drawString(vertices[i].getVelocidad()+"", vertices[i].getPosX()+18, vertices[i].getPosY()+23);
			}
			g2.setColor(Color.CYAN);
			g2.fillOval(tren.getPosX(), tren.getPosY(), 20, 20);
			
		}
		else if(grafoListaAd != null)
		{
			for(int i = 0; i < vertices.length; i++)
			{
				Vertex actual = vertices[i];
				ArrayList<int[]> aristas = grafoListaAd.get(actual.getCodigo());
				for(int j = 0; j < aristas.size();j++)
				{
					Vertex adyacente = vertices[aristas.get(j)[0]];
					g2.setColor(Color.BLACK);
					g2.setStroke(new BasicStroke(5));
					g2.drawLine(actual.getPosX()+20, actual.getPosY()+20, adyacente.getPosX()+20, adyacente.getPosY()+20);
				}
			}
			Vertex inicial = tren.getActual();
			g2.setColor(Color.green);
			g2.drawLine(inicial.getPosX()+20, inicial.getPosY()+20, seleccionado.getPosX()+20, seleccionado.getPosY()+20);
			g2.setStroke(new BasicStroke(2));
			g2.setColor(Color.RED);
			for(int i = 0; i < vertices.length; i++)
			{
				g2.fillOval(vertices[i].getPosX(), vertices[i].getPosY(), 40, 40);
			}
			g2.setColor(Color.CYAN);
			g2.fillOval(tren.getPosX(), tren.getPosY(), 20, 20);
			
			
			
		}
		
		
		
	}
	
	public void cambiarSeleccionadoDer(){
		if(grafoMatrizAd != null)
		{
			Vertex llegada=tren.getActual();
			int salida = Integer.parseInt(tren.getSalida().getCodigo());
			int fila = Integer.parseInt(llegada.getCodigo());
			int columna=Integer.parseInt(seleccionado.getCodigo());
			int valor=0;
			while(valor==0 ){
				if(columna+1>grafoMatrizAd[0].length-1){
					columna=-1;
				}else{
					if(columna+1!=salida){
						columna++;
						valor=grafoMatrizAd[fila][columna];
					}
					else{
						columna+=1;
					}
				}
			}
			seleccionado=vertices[columna];
		}
		else if(grafoListaAd != null)
		{
			int indice = -1;
			int indiceSalida = -1;
			for (int i = 0; i < grafoListaAd.get(tren.getActual().getCodigo()).size(); i++) 
			{
				if(grafoListaAd.get(tren.getActual().getCodigo()).get(i)[0] == Integer.parseInt(seleccionado.getCodigo()))
				{
					indice = i;
				}
				if(grafoListaAd.get(tren.getActual().getCodigo()).get(i)[0] == Integer.parseInt(tren.getSalida().getCodigo()))
				{
					indiceSalida = i;
				}
			}
			int proximo = indice + 1;
			if(proximo < grafoListaAd.get(tren.getActual().getCodigo()).size())
			{
				Vertex vertice = vertices[grafoListaAd.get(tren.getActual().getCodigo()).get(proximo)[0]];
				if(indiceSalida != proximo)
				{
					seleccionado = vertice;
					System.out.println(vertice.getCodigo() + " " + tren.getSalida().getCodigo());
				}
				else
				{
					proximo++;
					try 
					{
						seleccionado = vertices[grafoListaAd.get(tren.getActual().getCodigo()).get(proximo)[0]];
					}
					catch (Exception e) 
					{
						seleccionado = vertices[grafoListaAd.get(tren.getActual().getCodigo()).get(0)[0]];		
					}
					
				}
				
			}
			else
			{
				Vertex vertice = vertices[grafoListaAd.get(tren.getActual().getCodigo()).get(0)[0]];
				if(indiceSalida != proximo)
				{
					seleccionado = vertice;
				}
				else
				{
					seleccionado = vertices[grafoListaAd.get(tren.getActual().getCodigo()).get(1)[0]];
				}
			}
		}
	}
	public void cambiarSeleccionadoIzq(){
		if(grafoMatrizAd != null)
		{
			Vertex actual=tren.getActual();
			int salida = Integer.parseInt(tren.getSalida().getCodigo());
			int fila = Integer.parseInt(actual.getCodigo());
			int columna=Integer.parseInt(seleccionado.getCodigo());
			int valor=0;
			while(valor==0 ) {
				if(columna-1<0){
					columna=grafoMatrizAd[0].length;
				}else{
					if(columna-1!=salida){
						
						columna--;
						valor=grafoMatrizAd[fila][columna];
					}
					else{
						columna-=1;
					}
				}
			}
			seleccionado=vertices[columna];
		}
		else if(grafoListaAd != null)
		{
			int indice = 0;
			int indiceSalida = 0;
			for (int i = 0; i < grafoListaAd.get(tren.getActual().getCodigo()).size(); i++) 
			{
				if(grafoListaAd.get(tren.getActual().getCodigo()).get(i)[0] == Integer.parseInt(seleccionado.getCodigo()))
				{
					indice = i;
				}
				if(grafoListaAd.get(tren.getActual().getCodigo()).get(i)[0] == Integer.parseInt(tren.getSalida().getCodigo()))
				{
					indiceSalida = i;
				}
			}
			int proximo = indice - 1;
			if(proximo >= 0)
			{
				Vertex vertice = vertices[grafoListaAd.get(tren.getActual().getCodigo()).get(proximo)[0]];
				if(indiceSalida != indice)
				{
					seleccionado = vertice;
				}
				else
				{
					proximo--;
					try 
					{
						seleccionado = vertices[grafoListaAd.get(tren.getActual().getCodigo()).get(proximo)[0]];
					}
					catch (Exception e) 
					{
						seleccionado = vertices[grafoListaAd.get(tren.getActual().getCodigo()).get(grafoListaAd.get(tren.getActual().getCodigo()).size()-1)[0]];
	
					}
				}
				
			}
			else
			{
				Vertex vertice = vertices[grafoListaAd.get(tren.getActual().getCodigo()).get(grafoListaAd.get(tren.getActual().getCodigo()).size()-1)[0]];
				if(indiceSalida != indice)
				{
					seleccionado = vertice;
				}
				else
				{
					try
					{
						seleccionado = vertices[grafoListaAd.get(tren.getActual().getCodigo()).get(grafoListaAd.get(tren.getActual().getCodigo()).size()-2)[0]];
					}
					catch (Exception e) 
					{
						seleccionado = vertices[grafoListaAd.get(tren.getActual().getCodigo()).get(0)[0]];
					}
				}
			}
		}
		
	}
	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stu
		
	}
	@Override
	public void keyPressed(KeyEvent e) {
		int comando= e.getKeyCode();
		if(comando==KeyEvent.VK_RIGHT){
			cambiarSeleccionadoDer();
			repaint();
		}
		else if(comando==KeyEvent.VK_LEFT){
			cambiarSeleccionadoIzq();
			repaint();
		}else if(comando==KeyEvent.VK_K) {

			principal.setDijkstra(true);
			repaint();
		}
		
	}
	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	public Vertex getSeleccionado(){
		return seleccionado;
	}
	
	public void cambiarSeleccionado(){
		//seleccionado=tren.getActual();
		if(seleccionado.getTipo().equals(Vertex.VERTEX_GIRO)){
			cambiarSeleccionadoDer();
		}
	}
	
	public void mouseClicked(java.awt.event.MouseEvent e) {
		// TODO Auto-generated method stub
		int posX=e.getX();
		int posY=e.getY();
		if((posX>=700 && posX<=900) && (posY>=600 && posY<=700)){
			
			principal.setDijkstra(true);
		}
		
	}
}
