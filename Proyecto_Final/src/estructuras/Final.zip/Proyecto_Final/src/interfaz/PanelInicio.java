package interfaz;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
public class PanelInicio extends JPanel implements ActionListener{

	public final static String CARGAR= "Cargar";
	private JButton btn;
	private InterfazJuego principal;
	
	public PanelInicio(InterfazJuego v){
		principal=v;
		setLayout(new BorderLayout());
		btn=new JButton("Cargar");
		btn.setActionCommand(CARGAR);
		btn.addActionListener(this);
		add(btn,BorderLayout.CENTER);
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		String comando = e.getActionCommand();
		if(comando.equals(CARGAR)){
			principal.cargarArchivo();
		}
		
	}
}
