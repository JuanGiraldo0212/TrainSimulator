import static org.junit.Assert.*;

import org.junit.Test;

import mundo.Juego;
import mundo.Vertex;

public class JuegoTest {
	Juego juego;
	public void setUpEscenario1(){
		juego = new Juego();
		Vertex[] Vlist = new Vertex[5];
		Vlist[0] = new Vertex("0","Estacion",5,30,40);
		Vlist[1] = new Vertex("1","Estacion",5,60,80);
		Vlist[2] = new Vertex("2","Estacion",5,120,160);
		Vlist[3] = new Vertex("3","Estacion",5,70,30);
		Vlist[4] = new Vertex("4","Estacion",5,20,40);
		
		int[][] grafoMatrizAd = {{0,0,0,10,5},{0,0,0,2,8},{0,0,0,6,0},{10,2,6,0,1},{5,8,0,1,0}};
		
		juego.setGrafoMatrizAd(grafoMatrizAd);
		juego.setVertices(Vlist);
	}
	@Test
	public void test() {
		System.out.println(juego.kruskal(juego.getGrafoMatrizAd()));
		System.out.println(juego.aristasPrimKruskal(juego.kruskal(juego.getGrafoMatrizAd())));
		System.out.println(juego.pesosPrimKruskal(juego.kruskal(juego.getGrafoMatrizAd())));
	}

}
