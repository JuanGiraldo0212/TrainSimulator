package mundo;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.PriorityQueue;

import estructuras.DisjointNode;
import estructuras.DisjointSets;
import Excepciones.QueueException;
import auxiliares.CompararAristasPorPeso;
import estructuras.Queue;

public class Juego {
	
	private Vertex[] vertices;
	private Tren tren;
	private int[][] grafoMatrizAd;
	private Hashtable<String, ArrayList<int[]>> grafoListaAd;
	private int time;
	private boolean dijkstra;
	
	public Juego(){
		grafoMatrizAd=null;
		grafoListaAd = null;
		tren=new Tren(210, 200, Tren.DIR_ABAJO);
	}
	public void cargarGrafoListaAd(File file)
	{
		try 
		{
			BufferedReader br = new BufferedReader(new FileReader(file));
			int cantidadVertices = Integer.parseInt(br.readLine());
			grafoListaAd = new Hashtable<>(cantidadVertices);
			vertices = new Vertex[cantidadVertices];
			
			for(int i = 0; i < cantidadVertices; i++)
			{
				String [] datos=br.readLine().split(" ");
				vertices[i]= new Vertex(datos[0], datos[1], Integer.parseInt(datos[2]), Integer.parseInt(datos[3]), Integer.parseInt(datos[4]));
				grafoListaAd.put(vertices[i].getCodigo(), new ArrayList<>());
			}
			for(int i = 0; i < cantidadVertices; i++)
			{
				String[] relaciones=br.readLine().split(" ");
				for(int j = 0; j < relaciones.length; j++)
				{
					String [] info = relaciones[j].split(",");
					int[] datosArista = {Integer.parseInt(info[0]), Integer.parseInt(info[1])};
					grafoListaAd.get(vertices[i].getCodigo()).add(datosArista);
				}
			}
			br.close();
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		tren.setSalida(vertices[0]);
		tren.setActual(vertices[2]);
		
		
	}
	public void cargarGrafoMatrizAd(File arch){
		try {
			BufferedReader br = new BufferedReader(new FileReader(arch));
			int numGraf=Integer.parseInt(br.readLine());
			grafoMatrizAd = new int[numGraf][numGraf];
			vertices= new Vertex[numGraf];
			for(int i=0;i<numGraf;i++){
				String [] datos=br.readLine().split(" ");
				vertices[i]= new Vertex(datos[0], datos[1], Integer.parseInt(datos[2]), Integer.parseInt(datos[3]), Integer.parseInt(datos[4]));
			}
			for(int i=0;i<numGraf;i++){
				String[] relaciones=br.readLine().split(" ");
				for(int j=0;j<relaciones.length;j++){
					String [] info = relaciones[j].split(",");
					grafoMatrizAd[i][Integer.parseInt(info[0])]=Integer.parseInt(info[1]);
				}
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		tren.setSalida(vertices[0]);
		tren.setActual(vertices[1]);
		
		
	}
	
	public  String kruskal(int[][] grafoMatrizAd)
	{
		String mensaje = "";
		DisjointSets<Vertex> conjuntos = new DisjointSets<>();
		ArrayList<int[]> aristas = new ArrayList<>(); 
		for (int i = 0; i < vertices.length; i++) 
		{
			conjuntos.makeSet(vertices[i]);
		}
		for (int i = 0; i < grafoMatrizAd[0].length; i++) 
		{
			for (int j = 0; j < grafoMatrizAd.length; j++)
			{
				if(grafoMatrizAd[i][j] != 0)
				{
					int[] datos = {i, j, grafoMatrizAd[i][j]};
					aristas.add(datos);
				}
			}
		}
		aristas.sort(new CompararAristasPorPeso());
		ArrayList<int[]> aristasMTS = new ArrayList<>(); 
		for(int k = 0; k < aristas.size()&& aristasMTS.size() != vertices.length; k++) 
		{
			int[] datosArista = aristas.get(k);
			LinkedList<DisjointNode<Vertex>> set1 = conjuntos.findSet(vertices[datosArista[0]]);
			LinkedList<DisjointNode<Vertex>> set2 = conjuntos.findSet(vertices[datosArista[1]]);
			if(!(set1.getFirst().getValue().equals(set2.getFirst().getValue())))
			{
				aristasMTS.add(datosArista);
				conjuntos.union(vertices[datosArista[0]], vertices[datosArista[1]]);
			}
		}
		for (int i = 0; i < aristasMTS.size(); i++) 
		{
			int[] datosArista = aristasMTS.get(i);
			mensaje += vertices[datosArista[0]].getCodigo()+"-"+ vertices[datosArista[1]].getCodigo() + "," + datosArista[2] + " ";
		}
		return mensaje;
	}
	
	public String BFS(int[][] grafoMatrizAd) throws QueueException {
		String tree = "";
		//Ciclo para volver todos los vertices blancos.
		for(int i = 0; i < vertices.length; i++) {
			//actualiza a blanco
			vertices[i].setColor(Vertex.BLANCO);
			//asigna distancia infinita del vertice
			vertices[i].setDistancia(999999999);
		}
		//Vertice de inicio del BFS
		Vertex temp = vertices[0];
		//Asigna color gris al vertice de inicio
		temp.setColor(Vertex.GRIS);
		//asigna distancia 0 al vertice
		temp.setDistancia(0);
		//Estructura queue de apoyo para el algoritmo
		Queue<Vertex> Q = new Queue<>();
		//Se encola el vertice de inicio
		Q.enqueue(temp);
		

		while(!Q.isEmpty()){
		//Se desencola el vertice primero en la cola
		Vertex u = Q.dequeue();
		//Ciclo para recorrer los adyacentes de u. Se usa la matriz de adyacencia, de manera que la posicio X de la matriz sea constante (el codigo de u)
		//y la posicion Y de la matriz sea un j que recorre todos los vertices
		for(int j = 0; j < vertices.length; j++) {
			//Verifica que el vertice sea blanco y que sea adyacente
			if(grafoMatrizAd[Integer.parseInt(u.getCodigo())][j] != 0 && vertices[j].getColor()==Vertex.BLANCO) {
				//asigna color gris al vertice adyacente
				vertices[j].setColor(Vertex.GRIS);
				//Asigna la nueva distancia
				vertices[j].setDistancia(u.getDistancia()+1);
				//Se agrega el par (X,Y), donde X es padre y Y es hijo, a la salida "tree"
				tree+="("+u.getCodigo()+","+j+") ";
				//Se encola el vertice adyacente a u con el objetivo de luego revisar sus adyacentes.
				Q.enqueue(vertices[j]);
				
			}
		}
		//se asigna color negro a u, pues ya se revisaron todos sus adyacentes.
		u.setColor(Vertex.NEGRO);
			
		}
		
		return tree;
	}
	
	public String DFS(int[][] grafoMatrizAd) {
		String tree = "";
		//Todos los vertices se vuelven blancos
		for(int i = 0; i < vertices.length; i++) {
			vertices[i].setColor(Vertex.BLANCO);
		}
		//El tiempo que sera la distancia de cada vertice posteriormente, inicia en 0
		time = 0;
		//Se recorren todos los vertices blancos. Es decir, no visitados.
		for(int i = 0; i < vertices.length; i++) {
			if(vertices[i].getColor()==Vertex.BLANCO) {
				//recursion para cada arbol del bosque de arboles de expansion minima
				tree+=DFS_Visit(vertices[i],grafoMatrizAd);
				//Cada arbol del bosque se separa por "/ ".
				tree+="/ ";
			}
		}
		
		return tree;
	}
	
	public String DFS_Visit(Vertex u, int[][] grafoMatrizAd){
		
		String tree = "";
		time+=1;
		//Se asigna la distancia al vertice
		u.setDistancia(time);
		//Se da por descubierto el vertice, por lo que se vuelve gris.
		u.setColor(Vertex.GRIS);
		//Ciclo para recorrer vertices adyacentes.
		for(int j = 0; j < vertices.length; j++) {
			//Se chequea adyacencia y que no se halla descubierto
			if(grafoMatrizAd[Integer.parseInt(u.getCodigo())][j] != 0 && vertices[j].getColor()==Vertex.BLANCO) {
				//Se agrega el par (X,Y), donde X es padre y Y es hijo, a uno de los arboles. Tenga en cuenta que la salida del algoritmo entero puede ser un bosque
				tree+="("+u.getCodigo()+","+j+") ";
				//Recursion para revisar el adyacente del adyacente hasta descubrir todos. 
				tree+=DFS_Visit(vertices[j],grafoMatrizAd);
			}
		}
		//Se descubren todos sus adyacentes, se vuelve negro.
		u.setColor(Vertex.NEGRO);
		//se aumenta el tiempo.
		time+=1;
		
		return tree;
	}
	
	public String primMST(int grafoMatrizAd[][])
    {
        // Arreglo que guarda el arbol minimo de expansion
        int parent[] = new int[vertices.length];
 
        // Valores de los cuales se escoger la arista minima
        int key[] = new int [vertices.length];
 
        // Representa si el vertices esta o no en el arbol
        Boolean mstSet[] = new Boolean[vertices.length];
 
        for (int i = 0; i < vertices.length; i++)
        {
            key[i] = Integer.MAX_VALUE;
            mstSet[i] = false;
        }
        // Vertice 0 se escoge como el primer vertice del arbol
        parent[0] = -1; // El primer elemento es la raiz del arbol
 
        for (int count = 0; count < vertices.length-1; count++)
        {
            // Escoge el vertice de menor indice que no se encuentra en el arbol
            int u = minKey(key, mstSet);
 
            mstSet[u] = true;
 
            // Actualiza el peso, si es menor, de la interseccion entre el minimo y sus adyacentes que no estan en el arbol
            for (int v = 0; v < vertices.length; v++)
            {
                if (grafoMatrizAd[u][v]!=0 && mstSet[v] == false &&
                    grafoMatrizAd[u][v] <  key[v])
                {
                    parent[v]  = u;
                    key[v] = grafoMatrizAd[u][v];
                }
            }
        }
 
        String prim = "";
        for (int i = 1; i < vertices.length; i++)
            prim += parent[i]+","+ i+","+
                               grafoMatrizAd[i][parent[i]] + " ";
        return prim;
    }
	
	public int minKey(int key[], Boolean mstSet[])
    {
        int min = Integer.MAX_VALUE, min_index=-1;
 
        for (int v = 0; v < vertices.length; v++)
            if (mstSet[v] == false && key[v] < min)
            {
                min = key[v];
                min_index = v;
            }
 
        return min_index;
    }
	//Retorna en un string las aristas pertenecientes al arbol de expansion minima de prim, no ordenadamente
	public String aristasPrimKruskal(String aristaYpeso) 
	{
    	String[] arrDatos = aristaYpeso.split(" ");
    	String retorno ="";
    	for (int i = 0; i < arrDatos.length; i++) 
    	{
    		String[] aristas = arrDatos[i].split(",");
    		retorno+=aristas[0]+"\n";	
		}
    	return retorno;
    }
    //Retorna la suma de los pesos de las aristas pertenecientes al arbol de expansion minima de prim
	public int pesosPrimKruskal(String aristaYpeso) 
    {
    	String[] arrDatos = aristaYpeso.split(" ");
    	int retorno =0;
    	for (int i = 0; i < arrDatos.length; i++) 
    	{
    		String[] aristas = arrDatos[i].split(",");
    		retorno+=Integer.parseInt(aristas[1]);
		}
    	return retorno;
    }

	public int[] aristaMenorPeso(int[][] grafoMatrizAd)
	{
		int menor = Integer.MIN_VALUE;
		int fila = 0;
		int columna = 0;
		for (int i = 0; i < grafoMatrizAd[0].length; i++)
		{
			for (int j = 0; j < grafoMatrizAd.length; j++) 
			{
				if(menor > grafoMatrizAd[i][j])
				{
					menor = grafoMatrizAd[i][j];
					fila = i;
					columna = j;
					grafoMatrizAd[i][j] = 0;
				}
			}
		}
		int datos[] = {fila, columna};
		return datos;
	}
	
	/**
	 * 
	 * @param adyacencia es la matriz donde van a estar los pesos 
	 * @param inicio es el indice del vertice de inicio
	 * @param llegada es el indice del vertice de llegada
	 * @return un entero que representa el peso minimo desde inicio a llegada
	 */
	public int dijkstra(int [][] adyacencia,int inicio,int llegada){
        ArrayList<Integer> camino=new ArrayList<>();
        int[] pesos=new int[adyacencia.length];
        ArrayList<Integer> S = new ArrayList<Integer>();
        for(int i=0;i<adyacencia.length;i++){
            pesos[i]=99999;
        }
        pesos[inicio]=0;
        while(!S.contains(llegada)){
            int u=minimoEnArreglo(pesos,S);
            S.add(u);
            camino.add(u);
            int[] vertices=verticesNoEnS(pesos, S);
            for(int i=0;i<vertices.length;i++){
                if(pesos[u]+adyacencia[u][vertices[i]]<pesos[vertices[i]]){
                    pesos[vertices[i]]=pesos[u]+adyacencia[u][vertices[i]];
                }
            }
        }
        System.out.println(pesos[llegada]);
        return pesos[llegada];
    }

	/**
	 * 
	 * @param arr el arreglo de pesos
	 * @param val la lista de vertices
	 * @return el indice del vertice con peso minimo que no esta en la lista pasada por parametro
	 */
    public int minimoEnArreglo(int[] arr,ArrayList<Integer> val){
        int index=0;
        int min=99999;
        int[] aux=arr.clone();
        for(int i=0;i<val.size();i++){
            aux[val.get(i)]=Integer.MAX_VALUE;
        }
        for(int i=0;i<aux.length;i++){
            if(aux[i]<min){
                min=aux[i];
                index=i;
            }
        }
        return index;
    }
    
    /**
     * 
     * @param arr el arreglo de los pesos 
     * @param val la lista de vertices
     * @return un arreglo de indices que no estan en la lista 
     */
    public int[] verticesNoEnS(int[] arr,ArrayList<Integer> val){
        int[] temp=arr.clone();
        int[] vertices = new int[(temp.length)-val.size()];
        int index=0;
        for(int i=0;i<val.size();i++){
            temp[val.get(i)]=-1;
        }
        for(int i=0;i<temp.length;i++){
            if(temp[i]!=-1){
                vertices[index]=i;
                index++;
            }
        }
        return vertices;
    }
	
    /**
     * 
     * @param ad la lista de adyacencia con los pesos de las aristas como interceccion entre filas y columnas
     * @return una matriz con los pesos de los caminos minimos
     */
	public int[][] floydWarshall(int[][] ad){
		
		int[][] matriz = ad.clone();
		for(int k=0;k<ad.length;k++){
			for(int i=0;i<ad.length;i++){
				for(int j=0;j<ad.length;j++){
					if(matriz[i][j]>matriz[i][k]+matriz[k][j]){
						matriz[i][j]=matriz[i][k]+matriz[k][j];
					}
				}
			}
		}
		return matriz;
	}
	
	public int[][] getGrafoMatrizAd() {
		return grafoMatrizAd;
	}

	public void setGrafoMatrizAd(int[][] grafoMatrizAd) {
		this.grafoMatrizAd = grafoMatrizAd;
	}

	public Vertex[] getVertices() {
		return vertices;
	}

	public void setVertices(Vertex[] vertices) {
		this.vertices = vertices;
	}
	
	public Tren getTren(){
		return tren;
	}
	public Hashtable<String, ArrayList<int[]>> getGrafoListaAd() {
		return grafoListaAd;
	}
	public void setGrafoListaAd(Hashtable<String, ArrayList<int[]>> grafoListaAd) {
		this.grafoListaAd = grafoListaAd;
	}
	public boolean isDijkstra() {
		return dijkstra;
	}
	public void setDijkstra(boolean dijkstra) {
		this.dijkstra = dijkstra;
	}
	
}
