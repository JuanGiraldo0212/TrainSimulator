package estructuras;

public class Heap {

}
