package estructuras;

import java.util.LinkedList;

public class DisjointNode<T extends Comparable<T>> implements Comparable<T>{

	private T value;
	private LinkedList<DisjointNode<T>> set;
	
	public DisjointNode(T value, LinkedList<DisjointNode<T>> set)
	{
		this.value = value;
		this.set = set;
	}

	public T getValue() {
		return value;
	}

	public LinkedList<DisjointNode<T>> getSet() {
		return set;
	}

	public void setValue(T value) {
		this.value = value;
	}

	public void setSet(LinkedList<DisjointNode<T>> set) {
		this.set = set;
	}

	@Override
	public int compareTo(T o) {
		return value.compareTo(o);
	}
	
}
